# examples/example.py
import os, requests

url = 'https://api.primeengine.ai/v1/filter/symbolic'
key = os.getenv('PRIMEENGINE_API_KEY')
r = requests.post(url, json={'number':'12345'}, headers={'Authorization':f'Bearer {key}'})
print(r.json())