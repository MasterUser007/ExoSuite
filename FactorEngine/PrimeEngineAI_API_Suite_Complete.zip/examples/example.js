// examples/example.js
import fetch from 'node-fetch';
const url = 'https://api.primeengine.ai/v1/filter/symbolic';
const key = process.env.PRIMEENGINE_API_KEY;
(async()=>{ const r=await fetch(url,{method:'POST',headers:{'Authorization':`Bearer ${key}`,'Content-Type':'application/json'},body:JSON.stringify({number:'12345'})}); console.log(await r.json()); })();