# sdk/python/primeengine.py
import requests

class PrimeEngineClient:
    def __init__(self, api_key, base_url='https://api.primeengine.ai/v1'):
        self.base_url = base_url
        self.headers = {'Authorization': f'Bearer {api_key}'}

    def symbolic_filter(self, number):
        resp = requests.post(f'{self.base_url}/filter/symbolic',
                             json={'number': number},
                             headers=self.headers)
        resp.raise_for_status()
        return resp.json()
