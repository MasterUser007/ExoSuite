# PrimeEngineAI API Suite

See [openapi.yaml](openapi.yaml) for the complete spec.

## Setup
- Host `openapi.yaml` and `.well-known/ai-plugin.json` via HTTPS with CORS.
- Install `redoc-cli` or `swagger-ui` for docs in `docs/`.
- Generate SDKs via OpenAPI generator.

## Files
- `openapi.yaml`
- `.well-known/ai-plugin.json`
- `docs/` (Swagger UI)
- `examples/`
- `sdk/`
- `.github/workflows/ci.yml`, `pages.yml`
- `.postman/PrimeEngineAI.postman_collection.json`
- `.env.example`
- `tests/`
- `CONTRIBUTING.md`, `CODE_OF_CONDUCT.md`, `SECURITY.md`
