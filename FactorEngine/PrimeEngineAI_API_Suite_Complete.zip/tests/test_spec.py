def test_openapi_exists():
    assert __import__('os').path.exists('openapi.yaml')