# Contributing

Please read CODE_OF_CONDUCT.md. Submit PRs against `main`. Tests should pass in `tests/`.

